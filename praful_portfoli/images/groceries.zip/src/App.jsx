import { useState } from "react";
import "./App.css";
import { Grocery } from "./components/Grocery";

function App() {
    return (
        <div className="App">
            <Grocery />
        </div>
    );
}

export default App;
