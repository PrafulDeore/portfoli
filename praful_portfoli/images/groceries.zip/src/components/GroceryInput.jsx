import { useState } from "react";
import { GroceryList } from "./Grocerylist";

export function GroceryInput({ childData }) {
    const [text, setText] = useState();

    return (
        <div>
            <input
                type="text"
                onChange={(e) => {
                    setText(e.target.value);
                }}
            />
            <button
                onClick={() => {
                    childData(text);
                }}
            >
                Add item
            </button>
        </div>
    );
}
