import { useState } from "react";
import { GroceryInput } from "./GroceryInput";
import { GroceryList } from "./Grocerylist";
import { v4 as uuidv4 } from "uuid";

export function Grocery() {
    const [grocery, setGrocery] = useState([]);

    function childData(data) {
        const t = {
            title: data,
            id: uuidv4(),
        };
        setGrocery([...grocery, t]);
    }
    // console.log(title);
    function del(userId) {
        const delArr = grocery.filter((ele) => {
            return userId != ele.id;
        });
        setGrocery(delArr);
    }
    return (
        <div className="c">
            <h2>Grocery List</h2>
            <GroceryInput childData={childData} />
            {grocery.map((e) => {
                return <GroceryList groc={e} del={del} key={e.id} />;
            })}
        </div>
    );
}
