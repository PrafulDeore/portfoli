export const GroceryList = ({ groc, del }) => {
    return (
        <div>
            {groc.title}
            <button
                onClick={() => {
                    del(groc.id);
                }}
            >
                Delete
            </button>
        </div>
    );
};
